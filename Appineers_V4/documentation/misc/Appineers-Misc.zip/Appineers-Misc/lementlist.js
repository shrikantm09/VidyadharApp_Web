
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","APIConnectors"],["c","Connectors"],["c","DatabaseRequirements"],["c","ExtendAPI"],["c","ExtendAPIController"],["c","ExtendAPIModel"],["c","ExtendController"],["c","ExtendModel"],["c","ExtendModule"],["c","ExtendView"],["c","FilePermissions"],["c","ModuleConnectors"],["c","Requirements"],["c","ServerRequirements"]];
